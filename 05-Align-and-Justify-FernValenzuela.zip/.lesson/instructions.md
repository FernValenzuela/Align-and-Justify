# Instructions  

---

Add code to 'style.css' to recreate this picture:
![Screenshot](./assets/Screenshot.png)

You will only need to use variations of `align`
and `justify` as well as flex-direction to achieve this. Good luck!